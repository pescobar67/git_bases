

print('Este es el archivo principal del programa')