nombre = "Gaston"

for i in range(5):
    print(nombre)